import axios from 'axios';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'
import { toast } from 'react-toastify';


const spanStyle = {
    padding: '20px',
    background: '#efefef',
    color: '#000000'
  }
  
  const divStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundSize: 'cover',
    height: '400px'
  }
  const slideImages = [
    {
      url: 'images/11.jpg',
      caption: 'Slide 1'
    },
    {
      url: 'images/22.jpg',
      caption: 'Slide 2'
    },
    {
      url: 'images/44.jpg',
      caption: 'Slide 3'
    },
  ];

  

function Home() {

    const [productdata , setproductdata] = useState([]);

    async function fetchlatestproducts()
    {
        try
        {
            const resp = await axios.get(`http://localhost:9000/api/fetchlatestprods`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    setproductdata(resp.data.proddata)
                }
                else if(resp.data.statuscode===0)
                {
                    setproductdata([]);
                    toast.info("No product found");
                }
            }
            else
            {
                alert("Some error occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    useEffect(()=>
    {      
        fetchlatestproducts();      
    },[])

    return (
        <>
            <div className="slide-container">
                <Slide>
                {slideImages.map((slideImage, index)=> (
                    <div key={index}>
                    <div style={{ ...divStyle, 'backgroundImage': `url(${slideImage.url})` }}>
                        {/* <span style={spanStyle}>{slideImage.caption}</span> */}
                    </div>
                    </div>
                ))} 
                </Slide>
           </div>
            <div class="register">
                <div class="container">
                    <h2>Welcome to SuperMarket</h2>
                    {
                        productdata.length > 0 ?
                            <>
                                {
                                    productdata.map((item, index) =>
                                        <div className="col-md-4 top_brand_left" key={index}>
                                            <div className="hover14 column">
                                                <div className="agile_top_brand_left_grid">
                                                    <div className="agile_top_brand_left_grid1">
                                                        <figure>
                                                            <div className="snipcart-item block" >
                                                                <div className="snipcart-thumb">
                                                                    <Link to={`/details?pid=${item._id}`}>
                                                                        <img src={`uploads/${item.Picture}`} height="125"></img>
                                                                        <p>{item.Name}</p>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </figure>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                }
                            </> : <h2>No product is Added By Admin</h2>
                    }
                </div>
            </div>
        </>
    )
}
export default Home;