import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { userContext } from "../App";


function ContactUs() {

    const [uname, setuname] = useState();
    const [email, setemail] = useState();
    const [message, setmessage] = useState();
    

    const {udata, setudata} = useContext(userContext);


    const navi = useNavigate();

    async function onsend(e) 
    {
        e.preventDefault()
        const data = {uname , email , message , udata: udata.username}
        try 
        {
            const resp = await axios.post(`http://localhost:9000/api/ContactUs` , data)
            if (resp.status === 200) {
                if (resp.data.statuscode === 0) 
                {
                    toast.warning("Cannot contact due to some problem");
                }
                else if (resp.data.statuscode === 1) 
                {
                    toast.success("Contact Done")   
                }
            }
            else 
            {
                alert("Some Problem Occured")
            }
        }
        catch (e) {
            alert(e.message)
        }
    }

    useEffect(() => {
        if (sessionStorage.getItem("userdata") === null) 
        {
            navi("/login")
            toast.error("please login to access the page")
        }
    }, [])


    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Contact-Us</li>
                    </ol>
                </div>
            </div>

            <div class="about">
                <div class="w3_agileits_contact_grids">
                    <div class="col-md-6 w3_agileits_contact_grid_left">
                        {/* <div class="agile_map">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3950.3905851087434!2d-34.90500565012194!3d-8.061582082752993!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7ab18d90992e4ab%3A0x8e83c4afabe39a3a!2sSport+Club+Do+Recife!5e0!3m2!1sen!2sin!4v1478684415917" style="border:0"></iframe>
                        </div> */}
                        <div class="agileits_w3layouts_map_pos">
                            <div class="agileits_w3layouts_map_pos1">
                                <h3>Contact Info</h3>
                                <p>1234k Avenue, 4th block, New York City.</p>
                                <ul class="wthree_contact_info_address">
                                    <li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@example.com</a></li>
                                    <li><i class="fa fa-phone" aria-hidden="true"></i>+(0123) 232 232</li>
                                </ul>
                                <div class="w3_agile_social_icons w3_agile_social_icons_contact">
                                    <ul>
                                        <li><a href="#" class="icon icon-cube agile_facebook"></a></li>
                                        <li><a href="#" class="icon icon-cube agile_rss"></a></li>
                                        <li><a href="#" class="icon icon-cube agile_t"></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 w3_agileits_contact_grid_right">
                        <h2 class="w3_agile_header">Leave a<span> Message</span></h2>

                        <form name="contactform" onSubmit={onsend} >
                            <span class="input input--ichiro">
                                <input class="input__field input__field--ichiro" type="text" id="input-25" name="Name" placeholder=" " required onChange={(e)=>setuname(e.target.value)} />
                                <label class="input__label input__label--ichiro" for="input-25">
                                    <span class="input__label-content input__label-content--ichiro">Your Name</span>
                                </label>
                            </span>
                            <span class="input input--ichiro">
                                <input class="input__field input__field--ichiro" type="email" id="input-26" name="Email" placeholder=" " required onChange={(e)=>setemail(e.target.value)}/>
                                <label class="input__label input__label--ichiro" for="input-26">
                                    <span class="input__label-content input__label-content--ichiro">Your Email</span>
                                </label>
                            </span>
                            <textarea name="Message" placeholder="Your message here..." required onChange={(e)=>setmessage(e.target.value)}></textarea>
                            <input type="submit" value="Submit"   />
                        </form>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>

        </>
    )
}
export default ContactUs;