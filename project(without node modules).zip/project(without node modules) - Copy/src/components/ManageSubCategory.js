import axios from "axios";
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function ManageSubCategory() {

    const[pname , setpname]=useState();
    const[rate , setrate]=useState();
    const[dis , setdis]=useState();
    const[stock , setstock]=useState();
    const[descp , setdescp] = useState();
    const[catid , setcatid] = useState(null);
    const[catdata , setcatdata] = useState([]);
    const [picture,setpicture]=useState(null);
    const [msg,setmsg]=useState();
    const [productdata,setproductdata]=useState([]);
    const[edit , setedit] = useState(false)
    const[imgname , setimgname] = useState(false)
    const[prodid , setprodid] = useState()
    const fileInputRef = useRef(null);   // for cancel
    const navi = useNavigate();

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
        else
        {
            var uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navi("/login")
                toast.error("please login to access the admin page") 
            }
        }
    },[])


    async function fetchallcat()
    {
        try
        {
            const resp = await axios.get("http://localhost:9000/api/getallcat")
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    setcatdata(resp.data.categorydata)
                }
                else if(resp.data.statuscode===0)
                {
                    setcatdata([]);
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    
    useEffect(()=>
    {
        fetchallcat();
    },[])

    useEffect(()=>
    {
        if(catid!==null && edit===false)
        {
            fetchprodsbycat();      
        }  
    },[catid])

    async function fetchprodsbycat()
    {
        try
        {
            const resp = await axios.get(`http://localhost:9000/api/fetchproductbycatid?cid=${catid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    setproductdata(resp.data.proddata)
                }
                else if(resp.data.statuscode===0)
                {
                    setproductdata([]);
                    toast.info("No product found");
                }
            }
            else
            {
                alert("Some error occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    async function addproduct(e)
    {
        e.preventDefault()
        try
        {
            const fdata = new FormData();
            fdata.append("catid" , catid)
            fdata.append("pname" , pname)
            fdata.append("rate" , rate)
            fdata.append("dis" , dis)
            fdata.append("stock" , stock)
            fdata.append("descp" , descp)

            if(picture!==null)
            {
                fdata.append("picture",picture)
            }
            
            const resp = await axios.post("http://localhost:9000/api/addproduct" , fdata)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    toast.success("Product added successfully");
                    fetchprodsbycat();
                    canceldb();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warn("Product not added ");
                }
            }
            else
            {
                setmsg("Some Problem Occured")
            }
        }
        catch(e)
        {
            setmsg(e.message)
        }
    }


    async function ondelete(catid)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete")
            if(pass===true)
            {
                const resp = await axios.delete(`http://localhost:9000/api/delproduct?id=${catid}`)
                if(resp.status===200)
                {
                    if(resp.data.statuscode===1)
                    {
                        toast.success(resp.data.msg)
                        fetchprodsbycat();
                        canceldb();
                    }
                    else if(resp.data.statuscode===0)
                    {
                        toast.warn(resp.data.msg)
                    }
                }
                else
                {
                    alert("some problem occured")
                }
            }
        }
        catch(e)
        {
            setmsg(e.message)
        }
    }

    function onupdate(catitem)
    {
        setedit(true)
        setpname(catitem.Name)
        setrate(catitem.Rate)
        setdis(catitem.Discount)
        setstock(catitem.Stock)
        setdescp(catitem.Description)
        setimgname(catitem.Picture)
        setprodid(catitem._id)   // unique product id
        // setcatid(catitem.Catid)  // if u want to change category of product
    }

    function canceldb()
    {
        setedit(false)
        setpname("")
        setrate("")
        setdis("")
        setstock("")
        setdescp("")
        setimgname("")
        setprodid("")
        // setcatid("")
        setpicture(null)

        // Clear the file input field
        if (fileInputRef.current) 
        {
            fileInputRef.current.value = ''; // Reset the value to clear the input
        }

        fetchprodsbycat()   // on updateing if we change category of products but our decision changes midway before clicking update we cancel it  then selected category products will be shown on cancel
    }

    async function updatedb()
    {    
        try
        {
            const formdata = new FormData();
            formdata.append("productid" , prodid)   // unique id
            formdata.append("cid" , catid)  // if u want to change category of product
            formdata.append("upname" , pname)  //either old name or new name
            formdata.append("uprate" , rate) //either old name or new name
            formdata.append("updis" , dis) //either old name or new name
            formdata.append("upstock" , stock) //either old name or new name
            formdata.append("updescp" , descp) //either old name or new name

            formdata.append("oldpicname" , imgname)
            if(picture!==null)
            {
                formdata.append("uppic" , picture)
            }

            const resp = await axios.put("http://localhost:9000/api/updateproduct" , formdata)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    toast.success("Product Updated Successfully")
                    fetchprodsbycat();
                    canceldb();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warn("Category not updated");   
                    // onimage it is not working
                    // toast.success("Product Updated Successfully")
                    // fetchprodsbycat();
                    // canceldb();
                }
            }
            else
            {
                toast.warn("some error occured")
            }
        }
        catch(err)
        {
            toast.warn(err.message)
        }   
        
    }


    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Manage Sub-Category</li>
                    </ol>
                </div>
            </div>
           
           
            <div className="login">
                <div className="container">
                    <h2>Manage Products</h2>

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">

                        <form name="form1" onSubmit={addproduct}>   

                            <select name="subcat"  className="form-control" onChange={(e)=>setcatid(e.target.value)} required=" ">  
                                <option value="">Choose Category</option>
                                {
                                    catdata.map((item , index)=>
                                        <option value={item._id} key={index}>{item.catname}</option>
                                    )
                                }
                            </select>
                            <input type="text" name="prodname" value={pname} placeholder="Product Name" required=" " onChange={(e)=>setpname(e.target.value)} />
                            <input type="text" name="rate" value={rate} placeholder="Rate" required=" " onChange={(e)=>setrate(e.target.value)} /><br/>

                            <input type="text" name="dis" value={dis} placeholder="Discount(in percent, do not add % symbol)" required=" " onChange={(e)=>setdis(e.target.value)} /><br/>

                            <input type="text" name="stock" value={stock} placeholder="Stock" required=" " onChange={(e)=>setstock(e.target.value)} /><br/>
                            
                            <textarea name="des" placeholder="Description" className="form-control" required=" " value={descp} onChange={(e)=>setdescp(e.target.value)}></textarea><br/>

                            {
                                edit===true?
                                <>
                                    <img src={`uploads/${imgname}`}  height="100"/>
                                    Choose new image, if required<br/><br/>
                                </>:null
                            }

                            <input type="file" name="ppic" ref={fileInputRef} onChange={(e)=>setpicture(e.target.files[0])} /><br/>

                            {
                                edit===false?
                                <>
                                    <input type="submit" name="btn1" value="Add" />
                                </>:null
                            }
                            {
                                edit===true?
                                <>
                                    <input type="button" name="btn2" value="Update" onClick={updatedb}/>
                                    <input type="button" name="btn3" value="Cancel" onClick={canceldb} />
                                </>:null
                            }
                            
                        </form>
                    </div>
                    
                </div>
            </div>


            <div className="login">
                <div className="container">
                    {
                        productdata.length>0?
                        <>
                            <h2>Added Products</h2><br/>
                            <table className="table table-striped timetable_sub ">
                                <tbody >
                                    <tr >
                                        <th>Pic</th>
                                        <th>Name</th>
                                        <th>Rate</th>
                                        <th>Discount</th>
                                        <th>Stock</th>
                                        <th>Description</th>
                                        <th>Update</th>
                                        <th>Delete</th>
                                    </tr>
                                </tbody>
                            {
                                productdata.map((item , index)=>
                                    <tr key={index} >
                                        <td><img src={`uploads/${item.Picture}`} height="75"/></td>
                                        <td >{item.Name}</td>
                                        <td >{item.Rate}</td>
                                        <td >{item.Discount}</td>
                                        <td >{item.Stock}</td>
                                        <td >{item.Description}</td>
                                        <td><button className="btn btn-primary" onClick={()=>onupdate(item)}>Update</button></td>
                                        <td><button className="btn btn-danger" onClick={()=>ondelete(item._id)}>Delete</button></td>
                                    </tr>
                                )
                            }
                            </table><br/><br/>
                            {productdata.length} Products found
                        </>:null
                    }
                </div>
            </div>
        </>
        
    )
}
export default ManageSubCategory;