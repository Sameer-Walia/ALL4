import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function ViewOrders() {

    const[ordersdata , setordersdata]=useState([]);
    const[billamt , setbillamt]=useState([]);
    const navigate = useNavigate();

    async function fetchorders()
    {
        try
        {
            const resp = await axios.get("http://localhost:9000/api/getallorders")
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    setordersdata(resp.data.ordersdata)
                }
                else if(resp.data.statuscode===0)
                {
                    setordersdata([]);
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    
    useEffect(()=>
    {
        fetchorders();
    },[])

    async function onorderdel(id)
    {
        var userresp = window.confirm("Are you sure to Delete")

        if(userresp===true)
        {
            const resp = await axios.delete(`http://localhost:9000/api/delorder/${id}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    toast.success("Order Deleted Successfull")
                    fetchorders();
                }
                else if(resp.data.statuscode===0)
                {
                    alert("Order not Deleted")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }  
    }

    useEffect(()=>
    {
        // 0+76,0+765,0+456 ans will be 456(last one) in asynchronous function
        var gtotal=0;
        for(var x=0;x<ordersdata.length;x++) // it is synchronous function
        {
            gtotal=gtotal+ordersdata[x].billamt;  
        }
        setbillamt(gtotal);
        
    } , [ordersdata])

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
        else
        {
            var uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navigate("/login")
                toast.error("please login to access the admin page") 
            }
        }
    },[])
    
    async function updatestatus(id)
    {
        navigate("/updatestatus?oid=" + id)
    }

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">List of Orders</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    {
                        ordersdata.length>0?
                        <>
                            <h2>List Of Users</h2><br/>
                            <table className="table table-striped timetable_sub">
                                <tbody>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>State</th>
                                        <th>Address</th>
                                        <th>Pincode</th>
                                        <th>Bill Amount</th>
                                        <th>Username</th>
                                        <th>Date</th>
                                        <th>Payment Mode</th>
                                        <th>Status</th>
                                        <th>Update Status</th>
                                        <th>Delete</th>
                                    </tr>
                                 </tbody>
                            {
                                ordersdata.map((item , index)=>
                                    <tr key={index}>
                                        <td><Link to={`/vieworderitems?oid=${item._id}`}>{item._id}</Link></td>
                                        <td>{item.address.state }</td>
                                        <td>{item.address.area }</td>
                                        <td>{item.address.pincode}</td>
                                        <td>{item.billamt}</td>
                                        <td>{item.username}</td>
                                        <td>{item.OrderDate}</td>
                                        <td>{item.PayMode}</td>
                                        <td>{item.status}</td>
                                        <td><button className="btn btn-danger" onClick={()=>updatestatus(item._id)}>Update</button></td>
                                        <td><button className="btn btn-danger" onClick={()=>onorderdel(item._id)}>Delete</button></td>
                                    </tr>
                                )
                            }
                            </table><br/><br/>
                            {ordersdata.length} orders found<br/>
                            Rs.{billamt}/- is total bill <br/><br/>
                        </>:<h2>No orders Found</h2>
                    }
                </div>
            </div>

        </>
    )
}
export default ViewOrders;