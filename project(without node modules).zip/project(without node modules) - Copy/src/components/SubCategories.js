import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

function SubCategories() {
    const [params] = useSearchParams();
    const catid = params.get("cat")

    const [prodsdata, setprodsdata] = useState([])

    useEffect(() => 
    {
        // if(catid!=="")
        // {
            fetchprodbycat();
        // }
    }, [catid])

    async function fetchprodbycat() 
    {
        try 
        {
            const resp = await axios.get(`http://localhost:9000/api/fetchprodbycatid?cid=${catid}`)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    setprodsdata(resp.data.proddata)
                }
                else 
                {
                    setprodsdata([]);
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch (e) 
        {
            alert(e.message)
        }
    }

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/homepage"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Sub-Category</li>
                    </ol>
                </div>
            </div>
            <div className="login">
                <div className="container">
                    {
                        prodsdata.length > 0 ?
                            <>
                                {
                                    prodsdata.map((item, index) =>
                                        <div className="col-md-4 top_brand_left" key={index}>
                                            <div className="hover14 column">
                                                <div className="agile_top_brand_left_grid">
                                                    <div className="agile_top_brand_left_grid1">
                                                        <figure>
                                                            <div className="snipcart-item block" >
                                                                <div className="snipcart-thumb">
                                                                    <Link to={`/details?pid=${item._id}`}>
                                                                        <img src={`uploads/${item.Picture}`} height="125"></img>
                                                                        <p>{item.Name}</p>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </figure>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                }
                            </> : <h2>No product is Added By Admin</h2>
                    }
                </div>
            </div>
        </>
    )
}
export default SubCategories;