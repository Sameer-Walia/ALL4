import { Route, Routes } from "react-router-dom";
import Signup from "./Signup";
import Home from "./Home";
import Login from "./Login";
import SearchUser from "./SearchUser";
import UsersList from "./UsersList";
import ManageCategory from "./ManageCategory";
import ManageSubCategory from "./ManageSubCategory";
import ChangePassword from "./ChangePassword";
import Categories from "./Categories";
import SubCategories from "./SubCategories";
import ProdDetails from "./ProdDetails";
import ProdDetails1 from "./ProdDetails1";
import ShowCart from "./ShowCart";
import CheckOut from "./CheckOut";
import OrderSummary from "./OrderSummary";
import ViewOrders from "./ViewOrders";
import UpdateStatus from "./UpdateStatus";
import OrderItems from "./OrderItems";
import UserOrderHistory from "./UserOrderHistory";
import SearchProducts from "./SearchProducts";
import AdminHome from "./AdminHome";
import SearchOrderId from "./SearchOrderId";
import ContactUs from "./ContactUs";
import AdminContactUs from "./AdminContactUs";
import AdminHeader from "./AdminHeader";

function Siteroutes()
{
    return(
        <>
            <Routes>
                <Route path="/" element={<Home/>}></Route>
                <Route path="/home" element={<Home/>}></Route>
                <Route path="/signup" element={<Signup/>}></Route>
                <Route path="/login" element={<Login/>}></Route>
                <Route path="/searchuser" element={<SearchUser/>}></Route>
                <Route path="/userslist" element={<UsersList/>}></Route>
                <Route path="/managecategory" element={<ManageCategory/>}></Route>
                <Route path="/managesubcategory" element={<ManageSubCategory/>}></Route>
                <Route path="/changepassword" element={<ChangePassword/>}></Route>
                <Route path="/category" element={<Categories/>}></Route>
                <Route path="/subcategory" element={<SubCategories/>}></Route>
                {/* usercontext and sessionstorage is there */}
                <Route path="/details" element={<ProdDetails/>}></Route>
                <Route path="/details1" element={<ProdDetails1/>}></Route>
                <Route path="/showcart" element={<ShowCart/>}></Route>
                <Route path="/checkout" element={<CheckOut/>}></Route>
                <Route path="/ordersummary" element={<OrderSummary/>}></Route>
                <Route path="/vieworder" element={<ViewOrders/>}></Route>
                <Route path="/updatestatus" element={<UpdateStatus/>}></Route>
                <Route path="/vieworderitems" element={<OrderItems/>}></Route>
                <Route path="/userorderhistory" element={<UserOrderHistory/>}></Route>
                <Route path="/searchresults" element={<SearchProducts/>}></Route>
                {/* all encryption on change password , userpages and adminpages ordersummary checkout etc*/}
                {/* slider(front home page and validation) */}
                <Route path="/searchoderid" element={<SearchOrderId/>}></Route>
                <Route path="/contactus" element={<ContactUs/>}></Route>
                <Route path="/admincontactus" element={<AdminContactUs/>}></Route>
                <Route path="/adminhome" element={<AdminHome/>}></Route>
            </Routes>
        </>
    )
}
export default Siteroutes;