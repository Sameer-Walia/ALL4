import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Signup() {

    const [name, setname] = useState();
    const [phone, setphone] = useState();
    const [uname, setuname] = useState();
    const [pass, setpass] = useState();
    const [cpass, setcpass] = useState();
    const [terms, setterms] = useState(false);
    const [msg, setmsg] = useState();
    const navi = useNavigate();

    async function onregister(e) {
        e.preventDefault(); // it will pervent form from getting submit
        if (terms === true) {
            if (pass === cpass) 
            {
                const reqdata = { name, phone, uname, pass }
                try 
                {
                    const resp = await axios.post("http://localhost:9000/api/signup", reqdata)
                    // alert(resp.data.msg)
                    if(resp.status===200)
                    {
                        if(resp.data.statuscode===1)
                        {
                            toast.success("U have successfully Register")
                            navi("/login")
                        }
                        else if(resp.data.statuscode===0)
                        {
                            toast.warn(resp.data.msg)
                        }
                    }
                    else
                    {
                        alert("Some Problem Occured")
                    }
                }
                catch (err) 
                {
                    setmsg(err.message)
                }
            }
            else 
            {
                toast.warning("Password and Confirm Password doesnot Match")
            }
        }
        else 
        {
            setmsg("Please accept terms and condition")
        }
    }
    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Register Page</li>
                    </ol>
                </div>
            </div>

            <div className="register">
                <div className="container">
                    <h2>Register Here</h2>
                    <div className="login-form-grids">
                        <h5>profile information</h5>
                        <form name="form1" onSubmit={onregister}>
                            <input type="text" name="pname" placeholder="First Name..." required=" " minLength="3" onChange={(e) => setname(e.target.value)} /><br />
                            <input type="tel" name="phone" minLength="10" maxLength="10" placeholder="Phone..." required=" " onChange={(e) => setphone(e.target.value)} />
                            {/* className="form-control" */}
                            <h6>Login information</h6>
                            <input type="email" name="un" placeholder="Email Address(Username)" required=" " onChange={(e) => setuname(e.target.value)} />
                            
                            <input type="password" name="pass" placeholder="Password" required=" " minLength="6" onChange={(e) => setpass(e.target.value)} pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"/>

                            <input type="password" name="cpass" placeholder="Password Confirmation" minLength="6" required=" " onChange={(e) => setcpass(e.target.value)} />
                            <div className="register-check-box">
                                <div className="check">
                                    <label className="checkbox">
                                        <input type="checkbox" name="cbx1" onChange={(e) => setterms(e.target.checked)} /><i> </i>I accept the terms and conditions
                                    </label>
                                </div>
                            </div>
                            <input type="submit" name="btn" value="Register" /><br />
                            {msg}
                        </form>
                    </div>
                    <div className="register-home">
                        <Link to="/">Home</Link>
                    </div>
                </div>
            </div>

        </>
    )
}
export default Signup;