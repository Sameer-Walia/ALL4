import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function UsersList() {

    const[membersdata , setmembersdata]=useState([]);
    const navi = useNavigate();

    async function fetchUsers()
    {
        try
        {
            const resp = await axios.get("http://localhost:9000/api/getallusers")
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    setmembersdata(resp.data.usersdata)
                }
                else if(resp.data.statuscode===0)
                {
                    setmembersdata([]);
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    
    useEffect(()=>
    {
        fetchUsers();
    },[])

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
        else
        {
            var uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navi("/login")
                toast.error("please login to access the admin page") 
            }
        }
    },[])

    async function onmemdel(id)
    {
        var userresp = window.confirm("Are you sure to Delete")

        if(userresp===true)
        {
            const resp = await axios.delete(`http://localhost:9000/api/deluser/${id}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    toast.success("User Deleted Successfull")
                    fetchUsers();
                }
                else if(resp.data.statuscode===0)
                {
                    alert("User not Deleted")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }  
    }


    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">UsersList</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    {
                        membersdata.length>0?
                        <>
                            <h2>List Of Users</h2><br/>
                            <table className="table table-striped timetable_sub">
                                <tbody>
                                    <tr>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Username</th>
                                        <th>Delete</th>
                                    </tr>
                                 </tbody>
                            {
                                membersdata.map((item , index)=>
                                    <tr key={index}>
                                        <td>{item.pname}</td>
                                        <td>{item.phone}</td>
                                        <td>{item.username}</td>
                                        <td><button className="btn btn-danger" onClick={()=>onmemdel(item._id)}>Delete</button></td>
                                    </tr>
                                )
                            }
                            </table><br/><br/>
                            {membersdata.length} members found
                        </>:<h2>No User Found</h2>
                    }
                </div>
            </div>

        </>
    )
}
export default UsersList;